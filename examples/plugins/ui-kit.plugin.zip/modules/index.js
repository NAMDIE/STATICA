// src/core/plugin-sdk/capabilities.ts
var PLUGIN_CAPABILITIES = [
  {
    permission: "admin.navigation",
    label: "Add pages to the admin navigation",
    description: "Allows the plugin to add pages to the CMS admin sidebar and plugin page router.",
    risk: "low",
    surfaces: ["manifest", "admin"]
  },
  {
    permission: "cms.storage",
    label: "Read and write plugin backend storage",
    description: "Allows the plugin to read and write records in resources declared by its manifest.",
    risk: "medium",
    surfaces: ["admin", "editor", "server", "cms"]
  },
  {
    permission: "cms.routes",
    label: "Register backend CMS routes",
    description: "Allows the plugin server entrypoint to register authenticated backend routes.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "cms.hooks",
    label: "Subscribe to CMS lifecycle events and filters",
    description: "Allows the plugin server entrypoint to listen to CMS events (publish, content changes, page updates) and to register filters that transform values before they leave the CMS.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "editor.toolbar",
    label: "Add controls to the editor toolbar",
    description: "Allows the plugin editor entrypoint to add toolbar buttons.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.commands",
    label: "Register editor commands",
    description: "Allows the plugin editor entrypoint to register commands that can be invoked by editor UI.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.read",
    label: "Read editor state",
    description: "Allows the plugin to inspect the current editor store state.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.write",
    label: "Modify editor state",
    description: "Allows the plugin to mutate editor store state through a host transaction.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.canvas",
    label: "Add canvas overlays",
    description: "Allows the plugin to register canvas overlay React components — annotation pins, custom selection adornments, measurement tools — that mount on top of the rendered canvas via `editor.canvas.registerOverlay`.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.panels",
    label: "Add editor panels",
    description: "Allows the plugin to register panels that mount in the editor's left sidebar (custom inspectors, plugin dashboards, review queues).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "modules.register",
    label: "Register page builder modules",
    description: "Allows the plugin to ship new modules that show up in the canvas module library.",
    risk: "high",
    surfaces: ["editor", "manifest"]
  },
  {
    permission: "loops.register",
    label: "Register loop entity sources",
    description: "Allows the plugin to register data sources for the base.loop module (e.g. external collections, custom queries).",
    risk: "medium",
    surfaces: ["editor", "server", "manifest"]
  },
  {
    permission: "visualComponents.register",
    label: "Install Visual Components / templates into the site",
    description: "Allows the plugin to ship Visual Components, page templates, and class packs that are imported into the user's site on activation.",
    risk: "medium",
    surfaces: ["admin", "manifest"]
  },
  {
    permission: "frontend.scripts",
    label: "Inject scripts into published pages",
    description: "Allows the plugin to ship a JavaScript file that is loaded on every published page (analytics, third-party widgets, custom runtimes).",
    risk: "high",
    surfaces: ["frontend", "manifest"]
  },
  {
    permission: "frontend.tracker",
    label: "Receive frontend analytics events",
    description: "Allows the plugin to receive structured tracker events from published pages and store them in plugin-owned storage.",
    risk: "medium",
    surfaces: ["frontend", "server", "manifest"]
  },
  {
    permission: "unstable.internals",
    label: "Use unstable internal APIs",
    description: "Reserved for trusted first-party plugins that need unstable host internals.",
    risk: "dangerous",
    surfaces: ["admin", "editor", "server", "cms"]
  }
];
var capabilityByPermission = new Map(PLUGIN_CAPABILITIES.map((capability) => [capability.permission, capability]));
// src/core/plugin-sdk/builders/defineModule.ts
function defineModule(config) {
  if (typeof config.id !== "string" || !config.id.includes(".")) {
    throw new Error(`[plugin-sdk] Module id "${config.id}" must be namespaced as "<pluginId>.<name>".`);
  }
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    category: config.category,
    version: config.version ?? "1.0.0",
    defaults: config.defaults,
    schema: config.schema,
    canHaveChildren: config.canHaveChildren,
    htmlTag: config.htmlTag,
    render: (props, children) => config.render({ props, children }),
    ...config.preview ? { preview: (props, children) => config.preview({ props, children }) } : {}
  };
}
// src/core/plugin-sdk/builders/controls.ts
var control = {
  text(label, options = {}) {
    return { type: "text", label, ...options };
  },
  textarea(label, options = {}) {
    return { type: "textarea", label, ...options };
  },
  number(label, options = {}) {
    return { type: "number", label, ...options };
  },
  color(label, options = {}) {
    return { type: "color", label, ...options };
  },
  select(label, optionsOrOptionsList) {
    const list = Array.isArray(optionsOrOptionsList) ? optionsOrOptionsList : optionsOrOptionsList.options;
    const description = Array.isArray(optionsOrOptionsList) ? undefined : optionsOrOptionsList.description;
    return { type: "select", label, options: list, ...description ? { description } : {} };
  },
  toggle(label, options = {}) {
    return { type: "toggle", label, ...options };
  },
  image(label, options = {}) {
    return { type: "image", label, ...options };
  },
  url(label, options = {}) {
    return { type: "url", label, ...options };
  }
};
// src/core/plugin-sdk/builders/html.ts
var HTML_ESCAPE_RE = /[&<>"']/g;
var HTML_ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function escapeHtml(value) {
  return value.replace(HTML_ESCAPE_RE, (ch) => HTML_ESCAPE_MAP[ch]);
}
var RAW_BRAND = Symbol.for("@pagebuilder/plugin-sdk/raw");
function isRawHtml(value) {
  return Boolean(value) && typeof value === "object" && value[RAW_BRAND] === true;
}
function raw(value) {
  return { [RAW_BRAND]: true, value };
}
function renderInterpolation(value) {
  if (value === null || value === undefined)
    return "";
  if (typeof value === "string")
    return escapeHtml(value);
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  if (isRawHtml(value))
    return value.value;
  if (Array.isArray(value))
    return value.map(renderInterpolation).join("");
  console.warn("[plugin-sdk:html] Unsupported interpolation type", typeof value, value);
  return escapeHtml(String(value));
}
function html(strings, ...values) {
  let out = "";
  for (let i = 0;i < strings.length; i++) {
    out += strings[i];
    if (i < values.length)
      out += renderInterpolation(values[i]);
  }
  return out;
}
function safeUrl(value) {
  const s = String(value ?? "");
  if (/^javascript:/i.test(s) || /^vbscript:/i.test(s))
    return "#";
  return s;
}
// examples/plugins/ui-kit/shared/css.ts
var sharedCss = `
  .uikit-card{background:var(--uikit-card-bg,#fff);color:var(--uikit-card-fg,#0f172a);border:1px solid var(--uikit-card-border,#e5e7eb);border-radius:12px;padding:24px;font-family:inherit;line-height:1.55;}
  .uikit-stat{display:grid;gap:6px;font-family:inherit;}
  .uikit-stat__value{font-size:clamp(2rem,4vw,3rem);font-weight:700;line-height:1;color:var(--uikit-accent,#1d4ed8);}
  .uikit-stat__label{font-size:0.95rem;color:var(--uikit-muted,#64748b);}
  .uikit-feature{display:grid;gap:10px;font-family:inherit;}
  .uikit-feature__icon{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:10px;background:var(--uikit-accent-soft,#dbeafe);color:var(--uikit-accent,#1d4ed8);font-size:22px;}
  .uikit-feature__title{margin:0;font-size:1.1rem;font-weight:600;}
  .uikit-feature__body{margin:0;color:var(--uikit-muted,#475569);}
  .uikit-pricing{display:grid;gap:16px;padding:28px 24px;border-radius:14px;border:1px solid var(--uikit-card-border,#e5e7eb);background:var(--uikit-card-bg,#fff);font-family:inherit;}
  .uikit-pricing--featured{border-color:var(--uikit-accent,#1d4ed8);box-shadow:0 12px 32px rgba(29,78,216,0.15);}
  .uikit-pricing__name{margin:0;font-size:1.1rem;font-weight:600;color:var(--uikit-muted,#475569);}
  .uikit-pricing__price{display:flex;align-items:baseline;gap:6px;}
  .uikit-pricing__price strong{font-size:2.4rem;font-weight:700;color:var(--uikit-card-fg,#0f172a);line-height:1;}
  .uikit-pricing__price span{color:var(--uikit-muted,#64748b);}
  .uikit-pricing__features{margin:0;padding:0;list-style:none;display:grid;gap:6px;color:var(--uikit-card-fg,#0f172a);}
  .uikit-pricing__features li{padding-left:22px;position:relative;}
  .uikit-pricing__features li::before{content:"✓";position:absolute;left:0;color:var(--uikit-accent,#1d4ed8);font-weight:700;}
  .uikit-pricing__cta{display:inline-block;margin-top:8px;padding:10px 18px;border-radius:8px;background:var(--uikit-accent,#1d4ed8);color:#fff;text-decoration:none;font-weight:600;text-align:center;}
  .uikit-pricing--featured .uikit-pricing__cta{background:var(--uikit-card-fg,#0f172a);}
  .uikit-testimonial{display:grid;gap:14px;padding:24px;border-radius:12px;background:var(--uikit-quote-bg,#f8fafc);font-family:inherit;}
  .uikit-testimonial__quote{margin:0;font-size:1.05rem;line-height:1.6;color:var(--uikit-card-fg,#0f172a);}
  .uikit-testimonial__author{display:flex;flex-direction:column;}
  .uikit-testimonial__author strong{font-size:0.95rem;color:var(--uikit-card-fg,#0f172a);}
  .uikit-testimonial__author span{font-size:0.85rem;color:var(--uikit-muted,#64748b);}
  .uikit-callout{display:grid;grid-template-columns:auto 1fr;gap:14px;padding:18px 22px;border-radius:10px;background:var(--uikit-card-bg,#fff);border:1px solid;font-family:inherit;line-height:1.5;}
  .uikit-callout__icon{font-size:24px;line-height:1;}
  .uikit-callout__title{display:block;font-size:0.95rem;margin-bottom:2px;}
  .uikit-callout__text{margin:0;color:var(--uikit-muted,#475569);}
  .uikit-callout--info{border-color:#1d4ed8;}
  .uikit-callout--warning{border-color:#d97706;}
  .uikit-callout--danger{border-color:#dc2626;}
  .uikit-callout--success{border-color:#16a34a;}
`;

// examples/plugins/ui-kit/modules/callout.ts
var callout_default = defineModule({
  id: "acme.ui-kit.callout",
  name: "Callout",
  description: "Boxed text with a tone color, perfect for tip/warning/info blocks.",
  category: "UI Kit",
  htmlTag: "aside",
  defaults: {
    icon: "⚡",
    title: "Heads up",
    body: "This is a Showcase callout — install the pack and add me from the module library.",
    tone: "info"
  },
  schema: {
    icon: control.text("Icon (emoji or symbol)"),
    title: control.text("Title"),
    body: control.textarea("Body", { rows: 3 }),
    tone: control.select("Tone", [
      { label: "Info", value: "info" },
      { label: "Warning", value: "warning" },
      { label: "Danger", value: "danger" },
      { label: "Success", value: "success" }
    ])
  },
  render: ({ props }) => ({
    html: html`
      <aside class="uikit-callout uikit-callout--${props.tone}">
        <span class="uikit-callout__icon" aria-hidden="true">${props.icon}</span>
        <div class="uikit-callout__body">
          <strong class="uikit-callout__title">${props.title}</strong>
          <p class="uikit-callout__text">${props.body}</p>
        </div>
      </aside>
    `,
    css: sharedCss
  })
});

// examples/plugins/ui-kit/modules/testimonial.ts
var testimonial_default = defineModule({
  id: "acme.ui-kit.testimonial",
  name: "Testimonial",
  description: "Customer quote with attribution. Drop into a card or onto its own background.",
  category: "UI Kit",
  htmlTag: "figure",
  defaults: {
    quote: "Page Builder is the first CMS we adopted that didn't fight us.",
    author: "Alex Morgan",
    role: "Head of Design, Acme Inc."
  },
  schema: {
    quote: control.textarea("Quote", { rows: 3 }),
    author: control.text("Author name"),
    role: control.text("Author role")
  },
  render: ({ props }) => ({
    html: html`
      <figure class="uikit-testimonial">
        <blockquote class="uikit-testimonial__quote">“${props.quote}”</blockquote>
        <figcaption class="uikit-testimonial__author">
          <strong>${props.author}</strong>
          <span>${props.role}</span>
        </figcaption>
      </figure>
    `,
    css: sharedCss
  })
});

// examples/plugins/ui-kit/modules/stat.ts
var stat_default = defineModule({
  id: "acme.ui-kit.stat",
  name: "Stat Block",
  description: "Large number + supporting label.",
  category: "UI Kit",
  htmlTag: "div",
  defaults: {
    value: "99.9%",
    label: "Uptime measured across our edge network"
  },
  schema: {
    value: control.text("Value"),
    label: control.text("Label")
  },
  render: ({ props }) => ({
    html: html`
      <div class="uikit-stat">
        <div class="uikit-stat__value">${props.value}</div>
        <div class="uikit-stat__label">${props.label}</div>
      </div>
    `,
    css: sharedCss
  })
});

// examples/plugins/ui-kit/modules/featureCard.ts
var featureCard_default = defineModule({
  id: "acme.ui-kit.feature-card",
  name: "Feature Card",
  description: "Icon + title + body block. Stack three of them for a feature row.",
  category: "UI Kit",
  htmlTag: "div",
  defaults: {
    icon: "⚡",
    title: "Fast by default",
    body: "Built for performance — clean HTML, deduped CSS, no client runtime."
  },
  schema: {
    icon: control.text("Icon (emoji or symbol)"),
    title: control.text("Title"),
    body: control.textarea("Body", { rows: 3 })
  },
  render: ({ props }) => ({
    html: html`
      <div class="uikit-feature">
        <span class="uikit-feature__icon" aria-hidden="true">${props.icon}</span>
        <h3 class="uikit-feature__title">${props.title}</h3>
        <p class="uikit-feature__body">${props.body}</p>
      </div>
    `,
    css: sharedCss
  })
});

// examples/plugins/ui-kit/modules/pricingTier.ts
var pricingTier_default = defineModule({
  id: "acme.ui-kit.pricing-tier",
  name: "Pricing Tier",
  description: 'Single pricing card with name, price, feature list, and a CTA. Mark "featured" for the highlighted tier.',
  category: "UI Kit",
  htmlTag: "div",
  defaults: {
    name: "Pro",
    price: "$29",
    cadence: "/ month",
    features: `Unlimited pages
Custom domain
Priority support`,
    ctaLabel: "Start free trial",
    ctaHref: "#signup",
    featured: false
  },
  schema: {
    name: control.text("Tier name"),
    price: control.text("Price"),
    cadence: control.text("Cadence (e.g. /mo)"),
    features: control.textarea("Features (one per line)", { rows: 4 }),
    ctaLabel: control.text("CTA label"),
    ctaHref: control.url("CTA href"),
    featured: control.toggle("Highlight as featured")
  },
  render: ({ props }) => {
    const featuresList = String(props.features || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => html`<li>${line}</li>`).join("");
    const featured = props.featured ? " uikit-pricing--featured" : "";
    return {
      html: html`
        <div class="uikit-pricing${raw(featured)}">
          <h3 class="uikit-pricing__name">${props.name}</h3>
          <div class="uikit-pricing__price">
            <strong>${props.price}</strong>
            <span>${props.cadence}</span>
          </div>
          <ul class="uikit-pricing__features">${raw(featuresList)}</ul>
          <a class="uikit-pricing__cta" href="${safeUrl(props.ctaHref)}">${props.ctaLabel}</a>
        </div>
      `,
      css: sharedCss
    };
  }
});

// examples/plugins/ui-kit/__modules-facade.ts
var __modules_facade_default = [callout_default, testimonial_default, stat_default, featureCard_default, pricingTier_default];
export {
  __modules_facade_default as default
};
