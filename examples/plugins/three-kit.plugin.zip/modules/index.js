// src/core/plugin-sdk/capabilities.ts
var PLUGIN_CAPABILITIES = [
  {
    permission: "admin.navigation",
    label: "Add pages to the admin navigation",
    description: "Allows the plugin to add pages to the CMS admin sidebar and plugin page router.",
    risk: "low",
    surfaces: ["manifest", "admin"]
  },
  {
    permission: "cms.storage",
    label: "Read and write plugin backend storage",
    description: "Allows the plugin to read and write records in resources declared by its manifest.",
    risk: "medium",
    surfaces: ["admin", "editor", "server", "cms"]
  },
  {
    permission: "cms.routes",
    label: "Register backend CMS routes",
    description: "Allows the plugin server entrypoint to register authenticated backend routes.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "cms.hooks",
    label: "Subscribe to CMS lifecycle events and filters",
    description: "Allows the plugin server entrypoint to listen to CMS events (publish, content changes, page updates) and to register filters that transform values before they leave the CMS.",
    risk: "high",
    surfaces: ["server", "cms"]
  },
  {
    permission: "editor.toolbar",
    label: "Add controls to the editor toolbar",
    description: "Allows the plugin editor entrypoint to add toolbar buttons.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.commands",
    label: "Register editor commands",
    description: "Allows the plugin editor entrypoint to register commands that can be invoked by editor UI. Also grants registration of Command Spotlight palette commands (api.editor.palette.registerCommand) and live-search providers (api.editor.palette.registerProvider).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.read",
    label: "Read editor state",
    description: "Allows the plugin to inspect the current editor store state.",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "editor.store.write",
    label: "Modify editor state",
    description: "Allows the plugin to mutate editor store state through a host transaction.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.canvas",
    label: "Add canvas overlays",
    description: "Allows the plugin to register canvas overlay React components — annotation pins, custom selection adornments, measurement tools — that mount on top of the rendered canvas via `editor.canvas.registerOverlay`.",
    risk: "high",
    surfaces: ["editor"]
  },
  {
    permission: "editor.panels",
    label: "Add editor panels",
    description: "Allows the plugin to register panels that mount in the editor's left sidebar (custom inspectors, plugin dashboards, review queues).",
    risk: "medium",
    surfaces: ["editor"]
  },
  {
    permission: "modules.register",
    label: "Register page builder modules",
    description: "Allows the plugin to ship new modules that show up in the canvas module library.",
    risk: "high",
    surfaces: ["editor", "manifest"]
  },
  {
    permission: "loops.register",
    label: "Register loop entity sources",
    description: "Allows the plugin to register data sources for the base.loop module (e.g. external collections, custom queries).",
    risk: "medium",
    surfaces: ["editor", "server", "manifest"]
  },
  {
    permission: "visualComponents.register",
    label: "Install Visual Components / templates into the site",
    description: "Allows the plugin to ship Visual Components, page templates, and class packs that are imported into the user's site on activation.",
    risk: "medium",
    surfaces: ["admin", "manifest"]
  },
  {
    permission: "frontend.scripts",
    label: "Inject scripts into published pages",
    description: "Allows the plugin to ship a JavaScript file that is loaded on every published page (analytics, third-party widgets, custom runtimes).",
    risk: "high",
    surfaces: ["frontend", "manifest"]
  },
  {
    permission: "frontend.tracker",
    label: "Receive frontend analytics events",
    description: "Allows the plugin to receive structured tracker events from published pages and store them in plugin-owned storage.",
    risk: "medium",
    surfaces: ["frontend", "server", "manifest"]
  },
  {
    permission: "cms.schedule",
    label: "Register scheduled jobs",
    description: "Allows the plugin to register handlers that fire on a cadence (hourly / daily / weekly / monthly / every-N-minutes). Each handler runs inside the QuickJS sandbox with a per-fire wall-clock budget; the host scheduler tick drives dispatch and records run history.",
    risk: "high",
    surfaces: ["server"]
  },
  {
    permission: "unstable.internals",
    label: "Use unstable internal APIs",
    description: "Reserved for trusted first-party plugins that need unstable host internals.",
    risk: "dangerous",
    surfaces: ["admin", "editor", "server", "cms"]
  }
];
var capabilityByPermission = new Map(PLUGIN_CAPABILITIES.map((capability) => [capability.permission, capability]));
// src/core/plugin-sdk/builders/defineModule.ts
function defineModule(config) {
  if (typeof config.id !== "string" || !config.id.includes(".")) {
    throw new Error(`[plugin-sdk] Module id "${config.id}" must be namespaced as "<pluginId>.<name>".`);
  }
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    category: config.category,
    version: config.version ?? "1.0.0",
    defaults: config.defaults,
    schema: config.schema,
    canHaveChildren: config.canHaveChildren,
    htmlTag: config.htmlTag,
    ...config.dependencies ? { dependencies: config.dependencies } : {},
    ...config.editorRuntime ? { editorRuntime: config.editorRuntime } : {},
    render: (props, children) => config.render({ props, children }),
    ...config.preview ? { preview: (props, children) => config.preview({ props, children }) } : {}
  };
}
// src/core/plugin-sdk/builders/controls.ts
var control = {
  text(label, options = {}) {
    return { type: "text", label, ...options };
  },
  textarea(label, options = {}) {
    return { type: "textarea", label, ...options };
  },
  number(label, options = {}) {
    return { type: "number", label, ...options };
  },
  color(label, options = {}) {
    return { type: "color", label, ...options };
  },
  select(label, optionsOrOptionsList) {
    const list = Array.isArray(optionsOrOptionsList) ? optionsOrOptionsList : optionsOrOptionsList.options;
    const description = Array.isArray(optionsOrOptionsList) ? undefined : optionsOrOptionsList.description;
    return { type: "select", label, options: list, ...description ? { description } : {} };
  },
  toggle(label, options = {}) {
    return { type: "toggle", label, ...options };
  },
  image(label, options = {}) {
    return { type: "image", label, ...options };
  },
  url(label, options = {}) {
    return { type: "url", label, ...options };
  }
};
// src/core/plugin-sdk/builders/html.ts
var HTML_ESCAPE_RE = /[&<>"']/g;
var HTML_ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
function escapeHtml(value) {
  return value.replace(HTML_ESCAPE_RE, (ch) => HTML_ESCAPE_MAP[ch]);
}
var RAW_BRAND = Symbol.for("@pagebuilder/plugin-sdk/raw");
function isRawHtml(value) {
  return Boolean(value) && typeof value === "object" && value[RAW_BRAND] === true;
}
function renderInterpolation(value) {
  if (value === null || value === undefined)
    return "";
  if (typeof value === "string")
    return escapeHtml(value);
  if (typeof value === "number" || typeof value === "boolean")
    return String(value);
  if (isRawHtml(value))
    return value.value;
  if (Array.isArray(value))
    return value.map(renderInterpolation).join("");
  console.warn("[plugin-sdk:html] Unsupported interpolation type", typeof value, value);
  return escapeHtml(String(value));
}
function html(strings, ...values) {
  let out = "";
  for (let i = 0;i < strings.length; i++) {
    out += strings[i];
    if (i < values.length)
      out += renderInterpolation(values[i]);
  }
  return out;
}
// examples/plugins/three-kit/shared/css.ts
var sharedCss = `
  .threekit-stage{position:relative;display:block;width:100%;background:var(--threekit-bg,#0f172a);border-radius:var(--threekit-radius,12px);overflow:hidden;line-height:0;font-family:inherit;}
  .threekit-stage canvas{display:block;width:100%;height:100%;}
  .threekit-stage[data-aspect="square"]{aspect-ratio:1/1;}
  .threekit-stage[data-aspect="wide"]{aspect-ratio:16/9;}
  .threekit-stage[data-aspect="ultrawide"]{aspect-ratio:21/9;}
  .threekit-stage[data-aspect="portrait"]{aspect-ratio:4/5;}
  .threekit-stage[data-aspect="banner"]{aspect-ratio:32/9;}
  .threekit-stage--editor-empty{display:grid;place-items:center;min-height:240px;color:#cbd5e1;font:500 12px/1.5 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;letter-spacing:0.04em;text-transform:uppercase;background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%);}
  .threekit-stage--editor-empty::before{content:"three.js \\2014 preview on publish";opacity:0.75;}
  .threekit-hero{position:relative;display:block;width:100%;min-height:clamp(320px,55vh,520px);background:var(--threekit-bg,#020617);overflow:hidden;color:#f8fafc;font-family:inherit;}
  .threekit-hero canvas{position:absolute;inset:0;width:100%;height:100%;display:block;}
  .threekit-hero__content{position:relative;display:grid;gap:12px;align-content:center;justify-items:center;text-align:center;padding:clamp(48px,8vw,96px) clamp(20px,4vw,48px);min-height:inherit;z-index:1;}
  .threekit-hero__eyebrow{letter-spacing:0.22em;text-transform:uppercase;font-size:0.75rem;font-weight:600;color:rgba(248,250,252,0.7);}
  .threekit-hero__title{margin:0;font-size:clamp(2rem,5vw,3.4rem);font-weight:700;line-height:1.1;}
  .threekit-hero__body{margin:0;max-width:520px;color:rgba(226,232,240,0.85);font-size:1.05rem;line-height:1.6;}
`;

// examples/plugins/three-kit/shared/constants.ts
var THREE_VERSION = "0.169.0";
var THREE_VERSION_RANGE = `^${THREE_VERSION}`;

// examples/plugins/three-kit/shared/publish.ts
function encodeOptionsAttribute(value) {
  return JSON.stringify(value);
}
function buildStageHtml(options) {
  return html`
    <div
      class="threekit-stage"
      data-aspect="${options.aspect}"
      data-threekit-type="${options.type}"
      data-threekit-options="${encodeOptionsAttribute(options.options)}"
    >
      <canvas aria-hidden="true"></canvas>
    </div>
  `;
}
function buildHeroHtml(opts) {
  return html`
    <section
      class="threekit-hero"
      data-threekit-type="hero-background"
      data-threekit-options="${encodeOptionsAttribute(opts.options)}"
    >
      <canvas aria-hidden="true"></canvas>
      <div class="threekit-hero__content">
        <span class="threekit-hero__eyebrow">${opts.eyebrow}</span>
        <h1 class="threekit-hero__title">${opts.title}</h1>
        <p class="threekit-hero__body">${opts.body}</p>
      </div>
    </section>
  `;
}
function editorPlaceholderHtml(aspect) {
  return html`
    <div class="threekit-stage threekit-stage--editor-empty" data-aspect="${aspect}"></div>
  `;
}

// examples/plugins/three-kit/shared/sandbox.ts
function buildSandboxImports(extra) {
  const lines = [`import * as THREE from 'three';`];
  if (!extra)
    return lines.join(`
`);
  for (const imp of extra) {
    lines.push(`import { ${imp.named} } from 'three/examples/jsm/${imp.specifier}.js';`);
  }
  return lines.join(`
`);
}
var STAGE_STYLES = `
  :host,html,body{margin:0;padding:0;width:100%;height:100%;background:#0f172a;}
  .threekit-stage{position:relative;width:100%;height:100%;}
  .threekit-stage canvas{display:block;width:100%;height:100%;}
  .threekit-hero{position:relative;width:100%;height:100%;background:#020617;color:#f8fafc;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;}
  .threekit-hero canvas{position:absolute;inset:0;width:100%;height:100%;display:block;}
  .threekit-hero__content{position:relative;display:grid;gap:12px;align-content:center;justify-items:center;text-align:center;padding:48px 24px;min-height:100%;z-index:1;}
  .threekit-hero__eyebrow{letter-spacing:0.22em;text-transform:uppercase;font-size:0.75rem;font-weight:600;color:rgba(248,250,252,0.7);}
  .threekit-hero__title{margin:0;font-size:clamp(1.6rem,4vw,2.6rem);font-weight:700;line-height:1.1;}
  .threekit-hero__body{margin:0;max-width:480px;color:rgba(226,232,240,0.85);font-size:1rem;line-height:1.6;}
`;
function makeSandboxRuntime(config) {
  const imports = buildSandboxImports(config.extraImports);
  const containerOpen = config.hero ? `'<section class="threekit-hero"><canvas></canvas><div class="threekit-hero__content"><span class="threekit-hero__eyebrow"></span><h1 class="threekit-hero__title"></h1><p class="threekit-hero__body"></p></div></section>'` : `'<div class="threekit-stage"><canvas></canvas></div>'`;
  const source = `
${imports}

const STYLES = ${JSON.stringify(STAGE_STYLES)};

function ensureStyleSheet() {
  if (document.getElementById('threekit-sandbox-styles')) return;
  const style = document.createElement('style');
  style.id = 'threekit-sandbox-styles';
  style.textContent = STYLES;
  document.head.appendChild(style);
}

function applyHeroText(root, props) {
  const eyebrow = root.querySelector('.threekit-hero__eyebrow');
  const title = root.querySelector('.threekit-hero__title');
  const body = root.querySelector('.threekit-hero__body');
  if (eyebrow) eyebrow.textContent = String(props.eyebrow ?? '');
  if (title) title.textContent = String(props.title ?? '');
  if (body) body.textContent = String(props.body ?? '');
}

function buildOptions(props) {
  // Modules pass their full props bag as init options — same shape as the
  // published render. The init function reads only the keys it knows about.
  return props;
}

let current = null;

function init(THREE, canvas, options) {
${config.initSource}
}

export function mount(root, context) {
  ensureStyleSheet();
  root.innerHTML = ${containerOpen};
  const isHero = ${config.hero ? "true" : "false"};
  if (isHero) applyHeroText(root, context.props);
  const canvas = root.querySelector('canvas');
  if (!canvas) throw new Error('threekit-sandbox: canvas missing');
  const cleanup = init(THREE, canvas, buildOptions(context.props));
  current = { canvas, cleanup, isHero };
  return {
    update(nextRoot, nextContext) {
      // Re-init for clean state on any prop change. Three.js init costs
      // are negligible for these small scenes and avoids per-module
      // patching boilerplate. Hero text updates without a re-init.
      if (current?.cleanup) try { current.cleanup(); } catch (_) {}
      nextRoot.innerHTML = ${containerOpen};
      if (current?.isHero) applyHeroText(nextRoot, nextContext.props);
      const nextCanvas = nextRoot.querySelector('canvas');
      const nextCleanup = init(THREE, nextCanvas, buildOptions(nextContext.props));
      current = { canvas: nextCanvas, cleanup: nextCleanup, isHero: current?.isHero ?? false };
    },
    cleanup() {
      if (current?.cleanup) try { current.cleanup(); } catch (_) {}
      current = null;
    },
  };
}
`;
  return {
    sandbox: {
      source,
      minHeight: config.minHeight ?? (config.hero ? 320 : 280)
    }
  };
}

// examples/plugins/three-kit/modules/heroBackground.ts
var SANDBOX_SOURCE = `
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(options.background || '#020617');

  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 100);
  camera.position.set(0, 1.8, 4.2);
  camera.lookAt(0, 0, 0);

  const colorA = new THREE.Color(options.colorA || '#22d3ee');
  const colorB = new THREE.Color(options.colorB || '#a855f7');

  const geometry = new THREE.PlaneGeometry(12, 6, 96, 48);
  geometry.rotateX(-Math.PI / 2.4);

  const material = new THREE.ShaderMaterial({
    uniforms: {
      uTime:   { value: 0 },
      uAmp:    { value: Number(options.amplitude) || 0.55 },
      uFreq:   { value: Number(options.frequency) || 0.8 },
      uColorA: { value: colorA },
      uColorB: { value: colorB },
    },
    vertexShader: \`
      uniform float uTime;
      uniform float uAmp;
      uniform float uFreq;
      varying vec3 vPos;
      void main() {
        vec3 p = position;
        p.y += sin((p.x * uFreq) + uTime * 1.2) * uAmp;
        p.y += sin((p.z * uFreq * 1.3) + uTime * 0.8) * uAmp * 0.6;
        vPos = p;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    \`,
    fragmentShader: \`
      uniform vec3 uColorA;
      uniform vec3 uColorB;
      varying vec3 vPos;
      void main() {
        float mixT = clamp(0.5 + vPos.y * 0.6, 0.0, 1.0);
        vec3 c = mix(uColorA, uColorB, mixT);
        gl_FragColor = vec4(c, 1.0);
      }
    \`,
    wireframe: options.wireframe !== false,
  });

  const mesh = new THREE.Mesh(geometry, material);
  scene.add(mesh);

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);

  let raf = 0;
  let running = true;
  const speed = Number(options.speed) || 0.7;
  function tick(t) {
    if (!running) return;
    material.uniforms.uTime.value = t * 0.001 * speed;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    geometry.dispose();
    material.dispose();
    renderer.dispose();
  };
`;
var EDITOR_PLACEHOLDER = html`
  <section class="threekit-hero">
    <div class="threekit-hero__content">
      <span class="threekit-hero__eyebrow">Three.js Hero</span>
      <h1 class="threekit-hero__title">Live preview renders here</h1>
      <p class="threekit-hero__body">three.js — preview on publish</p>
    </div>
  </section>
`;
var heroBackground_default = defineModule({
  id: "acme.three-kit.hero-background",
  name: "Hero Background",
  description: "Full-width animated wave hero with eyebrow + title + body text on top.",
  category: "Three Kit",
  htmlTag: "section",
  defaults: {
    eyebrow: "INTRODUCING",
    title: "Built on Three.js",
    body: "Drag this module onto any page to ship a GPU-animated hero band — clean HTML, scoped CSS, zero framework runtime.",
    background: "#020617",
    colorA: "#22d3ee",
    colorB: "#a855f7",
    amplitude: 0.55,
    frequency: 0.8,
    speed: 0.7,
    wireframe: true
  },
  schema: {
    eyebrow: control.text("Eyebrow"),
    title: control.text("Title"),
    body: control.textarea("Body", { rows: 3 }),
    background: control.color("Background"),
    colorA: control.color("Wave color A"),
    colorB: control.color("Wave color B"),
    amplitude: control.number("Wave amplitude", { min: 0, max: 2, step: 0.05 }),
    frequency: control.number("Wave frequency", { min: 0.1, max: 4, step: 0.05 }),
    speed: control.number("Animation speed", { min: 0, max: 3, step: 0.1 }),
    wireframe: control.toggle("Wireframe")
  },
  dependencies: {
    three: THREE_VERSION_RANGE
  },
  editorRuntime: makeSandboxRuntime({
    aspect: "banner",
    initSource: SANDBOX_SOURCE,
    hero: true,
    minHeight: 320
  }),
  render: ({ props }) => ({
    html: buildHeroHtml({
      eyebrow: props.eyebrow,
      title: props.title,
      body: props.body,
      options: { ...props }
    }),
    css: sharedCss
  }),
  preview: () => ({
    html: EDITOR_PLACEHOLDER,
    css: sharedCss
  })
});

// examples/plugins/three-kit/modules/modelViewer.ts
var SANDBOX_SOURCE2 = `
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(options.background || '#0f172a');

  const camera = new THREE.PerspectiveCamera(45, 1, 0.05, 1000);
  camera.position.set(2.5, 1.8, 2.5);

  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const sun = new THREE.DirectionalLight(0xffffff, 1.5);
  sun.position.set(3, 5, 4);
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0xbfdbfe, 0.4);
  fill.position.set(-3, 2, -2);
  scene.add(fill);

  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.autoRotate = options.autoRotate !== false;
  controls.autoRotateSpeed = Number(options.autoRotateSpeed) || 1.5;
  controls.target.set(0, 0, 0);

  let activeModel = null;
  const loader = new GLTFLoader();
  const url = String(options.url || '');
  if (url) {
    loader.load(
      url,
      (gltf) => {
        const root = gltf.scene;
        const box = new THREE.Box3().setFromObject(root);
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        const scale = 1.8 / maxDim;
        root.position.sub(center.multiplyScalar(scale));
        root.scale.setScalar(scale);
        scene.add(root);
        activeModel = root;
      },
      undefined,
      (err) => { console.warn('[three-kit:model-viewer] load failed', err); },
    );
  }

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);

  let raf = 0;
  let running = true;
  function tick() {
    if (!running) return;
    controls.update();
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    controls.dispose();
    if (activeModel) {
      activeModel.traverse((node) => {
        if (node.isMesh) {
          node.geometry?.dispose?.();
          const m = node.material;
          if (Array.isArray(m)) m.forEach((mm) => mm?.dispose?.());
          else m?.dispose?.();
        }
      });
    }
    renderer.dispose();
  };
`;
var ASPECT = "wide";
var modelViewer_default = defineModule({
  id: "acme.three-kit.model-viewer",
  name: "Model Viewer",
  description: "Interactive glTF/GLB model with OrbitControls (drag to rotate, scroll to zoom).",
  category: "Three Kit",
  htmlTag: "div",
  defaults: {
    url: "https://threejs.org/examples/models/gltf/DamagedHelmet/glTF/DamagedHelmet.gltf",
    background: "#0f172a",
    autoRotate: true,
    autoRotateSpeed: 1.5
  },
  schema: {
    url: control.url("Model URL (.gltf or .glb)", {
      description: "Public HTTPS URL to a glTF/GLB asset. CORS must allow your site origin."
    }),
    background: control.color("Background"),
    autoRotate: control.toggle("Auto-rotate", {
      description: "When on, the model spins by itself until the visitor interacts."
    }),
    autoRotateSpeed: control.number("Auto-rotate speed", { min: 0, max: 8, step: 0.1 })
  },
  dependencies: {
    three: THREE_VERSION_RANGE
  },
  editorRuntime: makeSandboxRuntime({
    aspect: ASPECT,
    initSource: SANDBOX_SOURCE2,
    extraImports: [
      { specifier: "controls/OrbitControls", named: "OrbitControls" },
      { specifier: "loaders/GLTFLoader", named: "GLTFLoader" }
    ]
  }),
  render: ({ props }) => ({
    html: buildStageHtml({
      type: "model-viewer",
      aspect: ASPECT,
      options: { ...props }
    }),
    css: sharedCss
  }),
  preview: () => ({
    html: editorPlaceholderHtml(ASPECT),
    css: sharedCss
  })
});

// examples/plugins/three-kit/modules/text.ts
var SANDBOX_SOURCE3 = `
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(options.background || '#0f172a');

  const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100);
  camera.position.set(0, 0, 7);

  scene.add(new THREE.AmbientLight(0xffffff, 0.85));
  const key = new THREE.DirectionalLight(0xffffff, 1.2);
  key.position.set(2, 3, 5);
  scene.add(key);

  function buildTextTexture(text, color) {
    const dpr = 2;
    const w = 1024;
    const h = 256;
    const offscreen = document.createElement('canvas');
    offscreen.width = w * dpr;
    offscreen.height = h * dpr;
    const ctx = offscreen.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = color;
    ctx.font = '700 144px Inter, system-ui, -apple-system, "Segoe UI", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, h / 2);
    const texture = new THREE.CanvasTexture(offscreen);
    texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
    texture.needsUpdate = true;
    return texture;
  }

  const texture = buildTextTexture(String(options.text || 'Three.js'), options.color || '#f8fafc');
  const aspect = 1024 / 256;
  const height = 1.6;
  const geometry = new THREE.BoxGeometry(height * aspect, height, options.depth || 0.18);

  const sideColor = new THREE.Color(options.sideColor || options.color || '#22d3ee');
  const sideMaterial = new THREE.MeshStandardMaterial({
    color: sideColor,
    metalness: 0.55,
    roughness: 0.35,
  });
  const faceMaterial = new THREE.MeshStandardMaterial({
    map: texture,
    transparent: true,
    metalness: 0.1,
    roughness: 0.6,
  });
  // BoxGeometry materials order: +X, -X, +Y, -Y, +Z (front), -Z (back).
  const mesh = new THREE.Mesh(geometry, [
    sideMaterial, sideMaterial, sideMaterial, sideMaterial, faceMaterial, faceMaterial,
  ]);
  scene.add(mesh);

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);

  let raf = 0;
  let running = true;
  const speed = Number(options.speed) || 0.5;
  function tick(t) {
    if (!running) return;
    mesh.rotation.y = Math.sin(t * 0.0006 * speed) * 0.6;
    mesh.rotation.x = Math.sin(t * 0.0004 * speed) * 0.15;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    geometry.dispose();
    sideMaterial.dispose();
    faceMaterial.dispose();
    texture.dispose();
    renderer.dispose();
  };
`;
var ASPECT2 = "wide";
var text_default = defineModule({
  id: "acme.three-kit.text",
  name: "3D Text",
  description: "Spinning textured text panel — Three.js with a CanvasTexture glyph atlas.",
  category: "Three Kit",
  htmlTag: "div",
  defaults: {
    text: "Three.js",
    color: "#f8fafc",
    sideColor: "#22d3ee",
    background: "#0f172a",
    depth: 0.18,
    speed: 0.5
  },
  schema: {
    text: control.text("Text"),
    color: control.color("Face color"),
    sideColor: control.color("Edge color"),
    background: control.color("Background"),
    depth: control.number("Depth", { min: 0.02, max: 1, step: 0.02 }),
    speed: control.number("Wobble speed", { min: 0, max: 3, step: 0.1 })
  },
  dependencies: {
    three: THREE_VERSION_RANGE
  },
  editorRuntime: makeSandboxRuntime({
    aspect: ASPECT2,
    initSource: SANDBOX_SOURCE3
  }),
  render: ({ props }) => ({
    html: buildStageHtml({
      type: "text",
      aspect: ASPECT2,
      options: { ...props }
    }),
    css: sharedCss
  }),
  preview: () => ({
    html: editorPlaceholderHtml(ASPECT2),
    css: sharedCss
  })
});

// examples/plugins/three-kit/modules/particles.ts
var SANDBOX_SOURCE4 = `
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(options.background || '#020617');

  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 200);
  camera.position.set(0, 0, 30);

  const count = Math.max(100, Math.min(80000, Number(options.count) || 6000));
  const positions = new Float32Array(count * 3);
  const radius = Number(options.spread) || 36;
  for (let i = 0; i < count; i++) {
    // Uniform-ish sphere distribution; cheap and reads as a starfield.
    const r = Math.cbrt(Math.random()) * radius;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos((Math.random() * 2) - 1);
    positions[i * 3]     = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

  const material = new THREE.PointsMaterial({
    color: new THREE.Color(options.color || '#e2e8f0'),
    size: Number(options.size) || 0.08,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.9,
  });
  const points = new THREE.Points(geometry, material);
  scene.add(points);

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);

  let raf = 0;
  let running = true;
  const speed = Number(options.speed) || 0.4;
  function tick(t) {
    if (!running) return;
    points.rotation.y = t * 0.0001 * speed;
    points.rotation.x = Math.sin(t * 0.00005 * speed) * 0.2;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    geometry.dispose();
    material.dispose();
    renderer.dispose();
  };
`;
var ASPECT3 = "wide";
var particles_default = defineModule({
  id: "acme.three-kit.particles",
  name: "Particle Field",
  description: "Animated 3D particle cloud — starfield, dust, or floating points.",
  category: "Three Kit",
  htmlTag: "div",
  defaults: {
    count: 6000,
    color: "#e2e8f0",
    background: "#020617",
    size: 0.08,
    speed: 0.4,
    spread: 36
  },
  schema: {
    count: control.number("Particle count", { min: 100, max: 80000, step: 100 }),
    color: control.color("Particle color"),
    background: control.color("Background"),
    size: control.number("Particle size", { min: 0.01, max: 1, step: 0.01 }),
    speed: control.number("Rotation speed", { min: 0, max: 4, step: 0.1 }),
    spread: control.number("Field spread", { min: 5, max: 80, step: 1 })
  },
  dependencies: {
    three: THREE_VERSION_RANGE
  },
  editorRuntime: makeSandboxRuntime({
    aspect: ASPECT3,
    initSource: SANDBOX_SOURCE4
  }),
  render: ({ props }) => ({
    html: buildStageHtml({
      type: "particles",
      aspect: ASPECT3,
      options: { ...props }
    }),
    css: sharedCss
  }),
  preview: () => ({
    html: editorPlaceholderHtml(ASPECT3),
    css: sharedCss
  })
});

// examples/plugins/three-kit/modules/scene.ts
var ASPECT4 = "square";
var SANDBOX_SOURCE5 = `
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(options.background || '#0f172a');

  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(0, 0, Number(options.cameraDistance) || 4.5);

  scene.add(new THREE.AmbientLight(0xffffff, 0.5));
  const directional = new THREE.DirectionalLight(0xffffff, 1.4);
  directional.position.set(3, 4, 5);
  scene.add(directional);

  function geometryFor(kind) {
    switch (kind) {
      case 'sphere': return new THREE.SphereGeometry(1.1, 48, 32);
      case 'torus':  return new THREE.TorusGeometry(0.95, 0.32, 24, 80);
      case 'cone':   return new THREE.ConeGeometry(1.1, 1.8, 48);
      case 'cube':
      default:       return new THREE.BoxGeometry(1.5, 1.5, 1.5);
    }
  }

  const geometry = geometryFor(options.geometry);
  const material = new THREE.MeshStandardMaterial({
    color: new THREE.Color(options.color || '#22d3ee'),
    metalness: 0.4,
    roughness: 0.35,
    flatShading: options.geometry === 'cube',
  });
  const mesh = new THREE.Mesh(geometry, material);
  scene.add(mesh);

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);

  let raf = 0;
  let running = true;
  const speed = Number(options.speed) || 0.6;
  function tick(t) {
    if (!running) return;
    const s = speed * 0.001;
    mesh.rotation.x = t * s * 0.6;
    mesh.rotation.y = t * s;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    geometry.dispose();
    material.dispose();
    renderer.dispose();
  };
`;
var scene_default = defineModule({
  id: "acme.three-kit.scene",
  name: "Three.js Scene",
  description: "Rotating Three.js primitive with light and color controls.",
  category: "Three Kit",
  htmlTag: "div",
  defaults: {
    geometry: "cube",
    color: "#22d3ee",
    background: "#0f172a",
    speed: 0.6,
    cameraDistance: 4.5
  },
  schema: {
    geometry: control.select("Geometry", [
      { label: "Cube", value: "cube" },
      { label: "Sphere", value: "sphere" },
      { label: "Torus", value: "torus" },
      { label: "Cone", value: "cone" }
    ]),
    color: control.color("Material color"),
    background: control.color("Background"),
    speed: control.number("Rotation speed", { min: 0, max: 5, step: 0.1 }),
    cameraDistance: control.number("Camera distance", { min: 2, max: 12, step: 0.1 })
  },
  dependencies: {
    three: THREE_VERSION_RANGE
  },
  editorRuntime: makeSandboxRuntime({
    aspect: ASPECT4,
    initSource: SANDBOX_SOURCE5
  }),
  render: ({ props }) => ({
    html: buildStageHtml({
      type: "scene",
      aspect: ASPECT4,
      options: { ...props }
    }),
    css: sharedCss
  }),
  preview: () => ({
    html: editorPlaceholderHtml(ASPECT4),
    css: sharedCss
  })
});

// examples/plugins/three-kit/__modules-facade.ts
var __modules_facade_default = [heroBackground_default, modelViewer_default, text_default, particles_default, scene_default];
export {
  __modules_facade_default as default
};
